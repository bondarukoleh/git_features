function sayHi() {
  alert('Hi!');
}

function sayBye() {
  alert('Bye!');
}
